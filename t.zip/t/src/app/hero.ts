export class Hero {

id: number;
name: string;
power: string;



}
