
import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 1, name: 'Mr. Nice',power: 'flirt' },
  { id: 2, name: 'Narco' ,power: 'flirt' },
  { id: 3, name: 'Bombasto',power: 'flirt' },
  { id: 4, name: 'Celeritas' ,power: 'flirt'},
  { id: 5, name: 'Magneta' ,power: 'flirt'},
  { id: 6, name: 'RubberMan',power: 'flirt' },
  { id: 7, name: 'Dynama' ,power: 'flirt'},
  { id: 8, name: 'Dr IQ' ,power: 'flirt'},
  { id: 9, name: 'Magma',power: 'flirt' },
  { id: 10, name: 'Tornado' ,power: 'flirt' }
];